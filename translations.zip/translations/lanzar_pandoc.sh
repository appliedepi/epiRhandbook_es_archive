#!/bin/bash
pandoc Manual_R_Epi_es.docx -f docx -t markdown -o manual_para_rmd.Rmd
